<nav>
    <div>

        <form action="" method="post">

            <input type="submit" value="Ver Todas Estadisticas" name="VerTodasEstadisticas">
            
            <input type="submit" value="Cerrar Sesion" name="logout">
        </form>

    </div>
</nav>