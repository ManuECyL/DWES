<?php
    define('IP', '192.168.7.207');
    define('BBDD', 'ahorcado');
    define('USER', 'maria');
    define('PASS', 'maria');
?>